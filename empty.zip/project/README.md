django_project_template
=======================

This project template creates a Django 1.5 project with a base set of applications
